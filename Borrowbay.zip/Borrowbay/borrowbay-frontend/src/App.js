function App() {
  return (
    <div>
      <h1>Welcome to BorrowBay</h1>
      <p>Your frontend is working! 🚀</p>
    </div>
  );
}

export default App;
