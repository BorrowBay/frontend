const API_BASE_URL = "http://localhost:5050"; // Change to 5050 if backend runs on 5050
export default API_BASE_URL;
